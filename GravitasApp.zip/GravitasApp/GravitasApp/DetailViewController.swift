//
//  DetailViewController.swift
//  GravitasApp
//
//  Created by Ankita Bose on 24/06/16.
//  Copyright © 2016 Ankita Bose. All rights reserved.
//

import UIKit

class DetailViewController: UIViewController, UITableViewDataSource, UITableViewDelegate
{
    
    @IBOutlet var eventDetailImageView: UIImageView!
    @IBOutlet var eventDetailTableView: UITableView!

    override func viewDidLoad()
    {
        super.viewDidLoad()
        eventDetailTableView.backgroundColor = UIColor(red: 240.0/255.0, green: 240.0/255.0, blue: 240.0/255.0, alpha: 0.2)
        eventDetailTableView.separatorColor = UIColor(red: 240.0/255.0, green: 240.0/255.0, blue: 240.0/255.0, alpha: 0.8)
        eventDetailTableView.estimatedRowHeight = 36.0
        eventDetailTableView.rowHeight = UITableViewAutomaticDimension
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return 7
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell
    {
        let cell = tableView.dequeueReusableCellWithIdentifier("Cell5",forIndexPath: indexPath) as! DetailTableViewCell
        switch indexPath.row
        {
        case 0:
            cell.fieldLabel.text = "Name"
            //cell.valueLabel.text = events.name
        case 1:
            cell.fieldLabel.text = "Description"
            //cell.valueLabel.text = events.description
        case 2:
            cell.fieldLabel.text = "Type"
            //cell.valueLabel.text = events.type
        case 3:
            cell.fieldLabel.text = "Price"
            //cell.valueLabel.text = events.price
        case 4:
            cell.fieldLabel.text = "Category"
            //cell.valueLabel.text = events.category
        case 5:
            cell.fieldLabel.text = "Date"
            //cell.valueLabel.text = events.date
        case 6:
            cell.fieldLabel.text = "Club"
            //cell.valueLabel.text = events.club
        default:
            cell.fieldLabel.text = ""
            cell.valueLabel.text = ""
        }
        cell.backgroundColor = UIColor.clearColor()
        return cell
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
