//
//  CategoryTableViewCell.swift
//  GravitasApp
//
//  Created by Ankita Bose on 14/06/16.
//  Copyright © 2016 Ankita Bose. All rights reserved.
//

import UIKit

class CategoryTableViewCell: UITableViewCell
{

    override func awakeFromNib()
    {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(selected: Bool, animated: Bool)
    {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    @IBOutlet var nameLabel: UILabel!
    @IBOutlet var thumbnailImageView: UIImageView!

}
