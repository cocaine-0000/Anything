//
//  Events.swift
//  GravitasApp
//
//  Created by Ankita Bose on 18/06/16.
//  Copyright © 2016 Ankita Bose. All rights reserved.
//

import Foundation
class Events
{
    var name = ""
    var description = ""
    var type = ""
    var price = 0.00
    var category = ""
    var date = ""
    var club = ""
    var image = ""
    
    init(name: String, description: String, type: String, price: Double, category: String, date: String, club: String, image: String)
    {
        self.name = name
        self.description = description
        self.type = type
        self.price = price
        self.category = category
        self.date = date
        self.club = club
        self.image = image
    }
    
}
