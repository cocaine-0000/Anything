//
//  PriceTableViewController.swift
//  GravitasApp
//
//  Created by Ankita Bose on 14/06/16.
//  Copyright © 2016 Ankita Bose. All rights reserved.
//

import UIKit

class PriceTableViewController: UITableViewController
{
    
    let events: [Events] = [Events(name: "Code-a-thon", description: "24-hour coding competition,exciting price money of upto 16k", type: "Competition", price: 200.00, category: "Coding", date: "15/9/16", club: "CODE-CHEF-VIT", image: "codechef"),
        Events(name: "Morse-coding", description: "encoding an decoding morse codes, exciting price worth 10k", type: "Competition", price: 50.00, category: "Astronomy", date: "16/9/16", club: "SEDS-VIT", image: "astronomy"),
        Events(name: "sudo-code", description: "assemble all the clues and get to the ultimate coding, win exciting prizes worth 3k", type: "competition", price: 100.00, category: "Coding", date: "21/9/16", club: "IEEE-CS", image: "coding"),
        Events(name: "Auto-CAD", description: "you will be taught about all the machine parts and engines of auto-mobiles", type: "Workshop", price: 500.00, category: "Automobiles", date: "22/9/16", club: "ASME-VIT", image: "automobiles"),
        Events(name: "Musical Instruments", description: "Technicalities of all the musical instruments", type: "Workshop", price: 100.00, category: "Fun events", date: "22/9/16", club: "MUSIC CLUB", image: "musicalInstruments"),
        Events(name: "Mozilla days", description: "learn making websites using javascript and all the backend languages", type: "Workshop", price: 300.00, category: "Coding", date: "21/9/16", club: "MOZZILA FIREFOX", image: "Coding"),
        Events(name: "ROBOTIX", description: "Dive into the deep world of robots and learn to make your own bot", type: "Workshop", price: 1000.00, category: "ROBOTIX", date: "25/9/16", club: "ISTE", image: "robotics"),
        Events(name: "ios-fusion", description: "Dive into the deep world of ios apps and learn to make your own app", type: "Workshop", price: 1000.00, category: "CODING", date: "25/9/16", club: "APPLE DEVELOPERS GROUP", image: "coding"),
        Events(name: "app-a-thon", description: "Dive into the deep world of ios apps and make your own app to win exciting prizez", type: "Competition", price: 300.00, category: "CODING", date: "23/9/16", club: "APPLE DEVELOPERS GROUP", image: "coding")]
    
    var eventPriceDict = [Double : [String]]()
    var eventPriceSectionTitles = [Double]()
    
    func createEventPriceDict()
    {
        for event in events
        {
            let priceKey = event.price
            if var priceValues = eventPriceDict[priceKey]
            {
                priceValues.append(event.name)
                eventPriceDict[priceKey] = priceValues
            }
            else
            {
              eventPriceDict[priceKey] = [event.name]
            }
        }
        eventPriceSectionTitles = [Double](eventPriceDict.keys)
        eventPriceSectionTitles = eventPriceSectionTitles.sort({ $0 < $1 })
    }
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
         title = "PRICE"
        createEventPriceDict()
        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem()
    }

    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: - Table view data source

    override func numberOfSectionsInTableView(tableView: UITableView) -> Int
    {
        // #warning Incomplete implementation, return the number of sections
        return eventPriceSectionTitles.count
    }

    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        // #warning Incomplete implementation, return the number of rows
        let priceKey = eventPriceSectionTitles[section]
        if let priceValues = eventPriceDict[priceKey]
        {
            return priceValues.count
        }
        return 0
        
    }


    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell
    {
        let cellIdentifier4 = "Cell4"
        let cell = tableView.dequeueReusableCellWithIdentifier(cellIdentifier4, forIndexPath: indexPath)
        let priceKey = eventPriceSectionTitles[indexPath.section]
        if let priceValues = eventPriceDict[priceKey]
        {
             cell.textLabel?.text = priceValues[indexPath.row]
             // Convert the animal name to lower case and
             // then replace all occurrences of a space with an underscore
             /*let imageFilename = animalValues[indexPath.row].lowercaseString.stringByReplacingOccurrencesOfString(" ", withString: "_", options: [], range: nil)*/
             cell.imageView?.image =  UIImage(named: "events")
        }
        return cell
    }
    
    override func tableView(tableView: UITableView, titleForHeaderInSection section: Int) -> String?
    {
        let b : String=String(eventPriceSectionTitles[section]);
        return b
    }
    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?)
    {
            if segue.identifier == "showPriceDetail"
            {
                 if let indexPath = tableView.indexPathForSelectedRow
                 {
                    let destinationController = segue.destinationViewController as! DetailViewController
                    let currentCell = self.tableView.cellForRowAtIndexPath(indexPath)
                    print(currentCell!.textLabel!.text)
                    for destinationEvent in events
                    {
                         let b : String = String(destinationEvent.price)
                         if b == currentCell!.textLabel!.text
                         {
                             destinationController.currentEvent = destinationEvent
                             break
                         }
                    }
                 }
            }
    }

    /*
    // Override to support conditional editing of the table view.
    override func tableView(tableView: UITableView, canEditRowAtIndexPath indexPath: NSIndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */

    /*
    // Override to support editing the table view.
    override func tableView(tableView: UITableView, commitEditingStyle editingStyle: UITableViewCellEditingStyle, forRowAtIndexPath indexPath: NSIndexPath) {
        if editingStyle == .Delete {
            // Delete the row from the data source
            tableView.deleteRowsAtIndexPaths([indexPath], withRowAnimation: .Fade)
        } else if editingStyle == .Insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    */

    /*
    // Override to support rearranging the table view.
    override func tableView(tableView: UITableView, moveRowAtIndexPath fromIndexPath: NSIndexPath, toIndexPath: NSIndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(tableView: UITableView, canMoveRowAtIndexPath indexPath: NSIndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
