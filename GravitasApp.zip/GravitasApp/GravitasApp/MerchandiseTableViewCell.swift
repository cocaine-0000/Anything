//
//  MerchandiseTableViewCell.swift
//  GravitasApp
//
//  Created by Ankita Bose on 14/06/16.
//  Copyright © 2016 Ankita Bose. All rights reserved.
//

import UIKit

class MerchandiseTableViewCell: UITableViewCell
{

    override func awakeFromNib()
    {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(selected: Bool, animated: Bool)
    {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    @IBOutlet var merchandiseNameLabel: UILabel!
    @IBOutlet var marchandiseSizesLabel: UILabel!
    @IBOutlet var merchandisePriceLabel: UILabel!
    @IBOutlet var merchandiseThumbnailImageView: UIImageView!

}
