//
//  ViewController.swift
//  GravitasApp
//
//  Created by Ankita Bose on 14/06/16.
//  Copyright © 2016 Ankita Bose. All rights reserved.
//

import UIKit

class ViewController: UIViewController
{
    @IBOutlet var ratingButton:UIButton!

    override func viewDidLoad()
    {
        super.viewDidLoad()
        navigationItem.backBarButtonItem = UIBarButtonItem(title: "", style: .Plain, target: nil, action: nil)
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    var events: [Events] = [Events(name: "Code-a-thon", description: "24-hour coding competition,exciting price money of upto 16k", type: "Competition", price: "200", category: "Coding", date: "15/9/16", club: "CODE-CHEF", image: "codechef"),
        Events(name: "Morse-coding", description: "encoding an decoding morse codes, exciting price worth 10k", type: "Competition", price: "50", category: "Astronomy", date: "16/9/16", club: "SEDS", image: "astronomy"),
        Events(name: "sudo-code", description: "assemble all the clues and get to the ultimate coding, win exciting prizes worth 3k", type: "competition", price: "100", category: "Coding", date: "21/9/16", club: "IEEE-CS", image: "coding"),
        Events(name: "Auto-CAD", description: "you will be taught about all the machine parts and engines of auto-mobiles", type: "Workshop", price: "500", category: "Automobiles", date: "22/9/16", club: "ASME-VIT", image: "automobiles"),
        Events(name: "Musical Instruments", description: "Technicalities of all the musical instruments", type: "Workshop", price: "100", category: "Fun events", date: "22/9/16", club: "MUSIC CLUB", image: "musicalInstruments"),
        Events(name: "Mozilla days", description: "learn making websites using javascript and all the backend languages", type: "Workshop", price: "300", category: "Coding", date: "17/9/16", club: "Mozzila Firefox", image: "Coding"),
        Events(name: "ROBOTIX", description: "Dive into the deep world of robots and learn to make your own bot", type: "Workshop", price: "1000", category: "ROBOTIX", date: "25/9/16", club: "ISTE", image: "robotics")]
    
    @IBAction func close(segue:UIStoryboardSegue)
    {
        if let reviewViewController = segue.sourceViewController as?reviewViewController
        {
            if let rating = reviewViewController.rating
            {
                ratingButton.setImage(UIImage(named: rating), forState: UIControlState.Normal)
            }
        }
    }

}

