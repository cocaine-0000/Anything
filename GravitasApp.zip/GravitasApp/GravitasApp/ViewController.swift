//
//  ViewController.swift
//  GravitasApp
//
//  Created by Ankita Bose on 14/06/16.
//  Copyright © 2016 Ankita Bose. All rights reserved.
//

import UIKit

class ViewController: UIViewController
{
    @IBOutlet var ratingButton:UIButton!

    override func viewDidLoad()
    {
        super.viewDidLoad()
        navigationItem.backBarButtonItem = UIBarButtonItem(title: "", style: .Plain, target: nil, action: nil)
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func close(segue:UIStoryboardSegue)
    {
        if let reviewViewController = segue.sourceViewController as?reviewViewController
        {
            if let rating = reviewViewController.rating
            {
                ratingButton.setImage(UIImage(named: rating), forState: UIControlState.Normal)
            }
        }
    }
    
    @IBAction func unwindToHomeScreen(segue:UIStoryboardSegue)
    {
            
    }

}

